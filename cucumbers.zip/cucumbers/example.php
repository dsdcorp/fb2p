<?php                                    

  ini_set("max_execution_time", "0");
  ini_set("memory_limit", "-1");

include("xmlp.inc");
include("progress.inc");

$search_word='������';
$replace_word='�������';
$ignored_tags=array('a', 'img');

$in_str=@file_get_contents('./cucumbers1.txt');

progress_start(1);
$indexes=replace_text($in_str, $search_word, false, $ignored_tags);
progress_end(true);

progress_start(1);
$out_str=replace_text($in_str, $search_word, $replace_word, $ignored_tags);
progress_end(true);

@file_put_contents('./out_indexes.txt', implode(',', $indexes));
@file_put_contents('./out_replaced.txt', $out_str);

function replace_text($text, $from, $to=false, $ignore_tags=false) {
  if (!$ignore_tags) $ignore_tags=array();
  $ignore_tags=array_change_key_case(a2h($ignore_tags), CASE_LOWER);
  $struct=xmlp_data2struct_with_offset($text, array('tags_hash'=>$GLOBALS['XMLP_HTML_elements'], 'fix_known_tag_types'=>true,));
  if (!is_array($struct)) return false;

  if ($to!==false) {
    frt3($struct[0], $from, $to, $ignore_tags);
  } else return frt4($struct[0], $from, $ignore_tags);

  $out_data=array();
  xmlp_compile_struct($struct[0], $out_data, true);
  $out_data=implode('', $out_data);
  return $out_data;
}

function a2h($a) { $h=array(); $c=count($a); for ($i=0;$i<$c;$i++) $h[$a[$i]]=true; return $h; }

function frt1(&$data, $from, $to, $ignore_tags) {
  $cnt=count($data);
  for ($i=0;$i<$cnt;$i++) {
    if (is_array($data[$i])) {
       if (!array_key_exists($data[$i]['lname'], $ignore_tags) && array_key_exists('content', $data[$i]))
           frt1($data[$i]['content'], $from, $to, $ignore_tags);
    } else $data[$i]=str_ireplace($from, $to, $data[$i]);
  }
}

function frt2(&$data, $from, $to, $ignore_tags) {
  $si=0;
  $s=array();
  $s[$si]=array(&$data, -1, count($data));
  while ($si>-1) {
    if ((++$s[$si][1])<$s[$si][2]) {
      $tag=&$s[$si][0][$s[$si][1]];
      if (is_array($tag)) {
         if (!array_key_exists($tag['lname'], $ignore_tags) && array_key_exists('content', $tag)) {
            $s[++$si]=array(&$tag['content'], -1, count($tag['content']));
         }
      } else $s[$si][0][$s[$si][1]]=str_ireplace($from, $to, $s[$si][0][$s[$si][1]]);
    } else $si--;
  }
}

function frt3(&$data, $from, $to, $ignore_tags) {
  $si=0;
  $s=array();
  $s[$si]=array('arr'=>&$data, 'ind'=>-1, 'cnt'=>count($data));
  while ($si>-1) {
    if ((++$s[$si]['ind'])<$s[$si]['cnt']) {
      $tag=&$s[$si]['arr'][$s[$si]['ind']];
      if (is_array($tag)) {
         if (!array_key_exists($tag['lname'], $ignore_tags) && array_key_exists('content', $tag)) {
            $s[++$si]=array('arr'=>&$tag['content'], 'ind'=>-1, 'cnt'=>count($tag['content']));
         }
      } else $s[$si]['arr'][$s[$si]['ind']]=str_ireplace($from, $to, $s[$si]['arr'][$s[$si]['ind']]);
    } else $si--;
  }
}

function frt4(&$data, $needle, $ignore_tags) {
  $si=0;
  $s=array();
  $r=array();
  $s[$si]=array('arr'=>&$data, 'ind'=>-1, 'cnt'=>count($data));
  $lto=0;
  $lo=0;
  while ($si>-1) {
    if ((++$s[$si]['ind'])<$s[$si]['cnt']) {
      $tag=&$s[$si]['arr'][$s[$si]['ind']];
      if (is_array($tag)) {
         if (!array_key_exists($tag['lname'], $ignore_tags) && array_key_exists('content', $tag)) {
            $lto=$tag['end_offset'];
            $s[++$si]=array('arr'=>&$tag['content'], 'ind'=>-1, 'cnt'=>count($tag['content']));
         }
      } else {
//         $lo=0; while (($lo=stripos($s[$si]['arr'][$s[$si]['ind']], $needle, $lo))!==false) $r[]=sprintf("%08X",$lto+($lo++));
         $lo=0; while (($lo=stripos($s[$si]['arr'][$s[$si]['ind']], $needle, $lo))!==false) $r[]=$lto+($lo++);
      }
    } else $si--;
  }        
  return $r;
}

?>
